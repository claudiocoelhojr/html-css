#include <stdio.h>

void lerFuncionario(char *funcao, int *anos, int *h_contratadas, int *h_trabalhadas)
{
    do {
        printf("- Função: ");
        fflush(stdin);// Limpa o buffer de entrada.
        scanf("%c", &*funcao);
        switch (*funcao)
        {
            case 'P':
            case 'p':
            case 'A':
            case 'a':
            case 'G':
            case 'g':
                break;
            default:
                printf("Erro: função inválida. Digite novamente:\n");
        }
    } while (*funcao != 'P' && *funcao != 'p' &&*funcao != 'A' &&*funcao != 'a' &&*funcao != 'G' &&*funcao != 'g');

    do {
        printf("- Anos de experiência: ");
        scanf("%d", anos);
        if (*anos < 0)
        {
            printf("Erro: número de anos inválido. Digite novamente:\n");
            continue;// Retorna ao início do loop.
        }
    } while (*anos < 0);

    do {
        printf("- Horas contratadas no mês: ");
        scanf("%d", h_contratadas);
        if (*h_contratadas <= 0)
        {
            printf("Erro: número de horas contratadas inválido. Digite novamente:\n");
            continue;
        }
    } while (*h_contratadas <= 0);

    do {
        printf("- Horas trabalhadas no mês: ");
        scanf("%d", h_trabalhadas);
        if (*h_trabalhadas <= 0)
        {
            printf("Erro: número de horas trabalhadas inválido. Digite novamente:\n");
            continue;
        }
    } while (*h_trabalhadas <= 0);
}

float calcularSalario(char funcao, int anos, int h_contratadas, int h_trabalhadas, float *sal_bruto, int *excedente, float *inss, float *ir)
{
    int val_hora;
    float sal_liq;
    fflush(stdin);
    switch (funcao)
    {
    case 'P':
    case 'p':
        if (anos <= 2)
            val_hora = 25;
        else if (anos <= 5)
            val_hora = 30;
        else
            val_hora = 38;
        break;
    
    case 'A':
    case 'a':
        if (anos <= 2)
            val_hora = 45;
        else if (anos <= 5)
            val_hora = 55;
        else
            val_hora = 70;
        break;

    case 'G':
    case 'g':
        if (anos <= 2)
            val_hora = 85;
        else if (anos <= 5)
            val_hora = 102;
        else
            val_hora = 130;
        break;
    }

    if (h_trabalhadas <= h_contratadas)// Número de horas trabalhadas menor ou igual ao número de horas contratadas.
        *sal_bruto = val_hora * h_trabalhadas;
    
    else// Horas excedentes.
    {
        *excedente = h_trabalhadas - h_contratadas;
        if (*excedente <= 13)
            *sal_bruto = val_hora * h_contratadas + *excedente * val_hora * 1.23;
        else if (*excedente < 22)
            *sal_bruto = val_hora * h_contratadas + *excedente * val_hora * 1.37;
        else
            *sal_bruto = val_hora * h_contratadas  + *excedente * val_hora * 1.56;
    }

    *inss = *sal_bruto * 0.11;// Cálculo do INSS.
    if (*sal_bruto <= 2700)// Condicionais para cálculo do IR.
        *ir = (*sal_bruto - *inss) * 0.15;
    else if (*sal_bruto <= 4200)
        *ir = (*sal_bruto - *inss) * 0.2;
    else if (*sal_bruto > 4200)
        *ir = (*sal_bruto - *inss) * 0.3;
    else
        *ir = 0;

    sal_liq = *sal_bruto - *inss - *ir;
    return sal_liq;// Retorna o valor do salário líquido.
}

void imprimirFolhaPagamento(float sal_bruto, int excedente, float inss, float ir, float sal_liq)
{
        printf("- Salário bruto...(R$): R$ %.2f\n", sal_bruto);
        if (excedente > 0)
            printf("- Horas excedentes.(h): %d hr\n", excedente);
        printf("- Desconto INSS...(R$): R$ %.2f\n", inss);
        printf("- Desconto IR.....(R$): R$ %.2f\n", ir);
        printf("- Salário líquido.(R$): R$ %.2f\n", sal_liq);
}

int main()
{
    int qtd_funcionarios;

    printf("Digite a quantidade de funcionários: ");
    scanf("%d", &qtd_funcionarios);
    while (qtd_funcionarios <= 0)
    {
        printf("Erro: a quantidade de funcionários deve ser maior que 0. Informe novamente:\n");
        scanf("%d", &qtd_funcionarios);
    }

    for (int i = 1; i <= qtd_funcionarios; i++)
    {
        char funcao;
        int anos, h_contratadas, h_trabalhadas, val_hora, excedente;
        float sal_bruto, inss, ir, sal_liq;

        printf("====================================");
        printf("\nFuncionário %d:\n", i);
        lerFuncionario(&funcao, &anos, &h_contratadas, &h_trabalhadas);// Chamada por referência.
        sal_liq = calcularSalario(funcao, anos, h_contratadas, h_trabalhadas, &sal_bruto, &excedente, &inss, &ir);
        printf("\nFolha de pagamento do funcionário %d:\n", i);
        imprimirFolhaPagamento(sal_bruto, excedente, inss, ir, sal_liq);// Chamada por valor.
    }

    return 0;    
}