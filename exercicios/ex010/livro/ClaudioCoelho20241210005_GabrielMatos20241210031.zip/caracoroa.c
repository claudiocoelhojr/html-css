#include <stdio.h>

int main()
{
    int n;

    do {
    printf("Insira o número de jogadas: ");// Lê a quantidade de jogadas na partida.
    scanf("%d", &n);
    if (n == 0)// Flag para encerrar o programa.
        break;
    if (n < 1 || n > 10000)// Verifica se o número de jogadas está dentro do intervalo desejado.
    {
        printf("\nErro: número de jogadas inválido.\n");
        continue; // Retorna ao início do loop para pedir novamente o número de jogadas.
    }
    int rodada, v_maria = 0, v_joao = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &rodada);
        if (rodada == 1)
            v_joao++;
        else if (rodada == 0)
            v_maria++;
        else// Testa se o resultado de uma rodada é diferente de 0 ou 1.
        {
            printf("\nErro: número da rodada inválido. Rodada abortada.\n");
            fflush(stdin);// Limpa o buffer de entrada.
            break;
        }
    }
    if (v_joao + v_maria == n)
        printf ("Maria venceu %d vez(es) e João venceu %d vez(es).\n", v_maria, v_joao);
    
    } while (n != 0);
    
    return 0;
}