#include <stdio.h>

int main()
{
    float x, arctan;
    float y;// Essa variável irá representar o termo x²ⁱ⁺¹.
    int n, i = 0, sinal = 1;// Variável "sinal" para representar o termo (-1)ⁱ na condição inicial (i = 0).

    printf("Insira um valor no intervalo ]-1, 1[: ");
    scanf("%f", &x);
    while (x <= -1 || x >= 1)
    {
        printf("\nInsira um valor dentro do intervalo mencionado: ");
        scanf("%f", &x);
    }

    printf("Insira o número de termos da série: ");
    scanf("%d", &n);
    while (n < 0)
    {
        printf("\nO número da termos da série deve ser maior ou igual a 0: ");
        scanf("%d", &n);
    }

    y = x; //Valor inicial (i = 0) para o termo x²*⁰⁺¹ = x¹ = x.
    for (i = 0; i <= n; i++)
    {
        arctan += sinal * y / (2 * i + 1);// Somatória dos valores de arctan.
        sinal *= -1;// Alterna o valor do sinal a cada execução da estrutura de controle entre -1 e 1.
        y *=  x * x;// Aumenta o expoente do termo x²ⁱ⁺¹ a cada execução da estrutura de controle.
    }

    printf("arctan(%f) = %f\n\n", x, arctan);
    return 0;
}